import torch
import numpy as np
import torch.nn as nn
import t3nsor as t3


class TTEmbedding(nn.Module):
    def __init__(self,
                 init=None,
                 shape=None,
                 voc_size=None,
                 emb_size=None,
                 auto_shapes=None,
                 auto_shape_mode='ascending',
                 auto_shape_criterion='entropy',
                 d=3,
                 tt_rank=8,
                 stddev=None,
                 batch_dim_last=None,
                 padding_idx=None):

        super(TTEmbedding, self).__init__()

        if auto_shapes:
            voc_quantization = t3.utils.suggest_shape(
                voc_size, d=d, criterion=auto_shape_criterion, mode=auto_shape_mode)
            emb_quantization = t3.utils.auto_shape(
                emb_size, d=d, criterion=auto_shape_criterion, mode=auto_shape_mode)

            shape = [voc_quantization, emb_quantization]
            self.shape = shape

        else:
            self.shape = shape

        if init is None:
            if shape is None:
                raise ValueError("if init is not provided, please specify shape")
        else:
            self.shape = init.raw_shape


        if init is None:
            init = t3.glorot_initializer(self.shape, tt_rank=tt_rank)

        self.tt_matrix = init.to_parameter()
        self.parameters = self.tt_matrix.parameter

        # for p in self.parameters():
        #    p.name = 'tt_core'

        self.batch_dim_last = batch_dim_last
        self.voc_size = int(np.prod(self.shape[0]))
        self.emb_size = int(np.prod(self.shape[1]))

        self.voc_quant = self.shape[0]
        self.emb_quant = self.shape[1]

        self.padding_idx = padding_idx

    def forward(self, x):

        xshape = list(x.shape)
        xshape_new = xshape + [self.emb_size, ]
        x = x.view(-1)

        # x_ind = t3.ind2sub(self.voc_quant, x)
        # rows = t3.gather_rows(self.tt_matrix, x_ind)

        # rows = rows.view(x.shape[0], -1)

        full = self.tt_matrix.full()
        rows = full[x]

        if self.padding_idx is not None:
            rows = torch.where(x.view(-1, 1) != self.padding_idx, rows, torch.zeros_like(rows))

        rows = rows.view(*xshape_new)

        return rows.to(x.device)


class TTLinear(nn.Module):
    def __init__(self, in_features=None, out_features=None, bias=True, init=None, shape=None,
                 auto_shapes=True, d=3, tt_rank=8, stddev=None, auto_shape_mode='ascending',
                 auto_shape_criterion='entropy',
                 ):

        super(TTLinear, self).__init__()

        if auto_shapes:
            if in_features is None or out_features is None:
                raise ValueError("Shape is not specified")

            in_quantization = t3.utils.auto_shape(
                in_features, d=d, criterion=auto_shape_criterion, mode=auto_shape_mode)
            out_quantization = t3.utils.auto_shape(
                out_features, d=d, criterion=auto_shape_criterion, mode=auto_shape_mode)

            shape = [in_quantization, out_quantization]

        if init is None:
            if shape is None:
                raise ValueError(
                    "if init is not provided, please specify shape, or set auto_shapes=True")
        else:
            shape = init.raw_shape

        if init is None:
            init = t3.glorot_initializer(shape, tt_rank=tt_rank)

        self.shape = shape
        self.weight = init.to_parameter()
        self.parameters = self.weight.parameter
        self.weight_t = t3.transpose(self.weight)

        if bias:
            self.bias = torch.nn.Parameter(1e-2 * torch.ones(out_features))
        else:
            self.register_parameter('bias', None)

    def forward(self, x):
        weight_t = self.weight_t
        x_t = x.transpose(0, 1)

        if self.bias is None:
            return t3.tt_dense_matmul(weight_t, x_t).transpose(0, 1)
        else:
            return t3.tt_dense_matmul(weight_t, x_t).transpose(0, 1) + self.bias


class Solver(nn.Module):
    def __init__(self,
                in_features=None,
                out_features=None,
                bias=True,
                init=None,
                shape=None,
                auto_shapes=True,
                d=3,
                tt_rank=8,
                iter_num=3,
                l=1,
                s=-2,
                epsilon=0.5,
                auto_shape_mode='ascending',
                auto_shape_criterion='entropy'):

        super(Solver, self).__init__()

        if auto_shapes:
            print('auto_shape working...')
            if in_features is None or out_features is None:
                raise ValueError("Shape is not specified")

            in_quantization = t3.utils.auto_shape(
            in_features, d=d, criterion=auto_shape_criterion, mode=auto_shape_mode)
            out_quantization = t3.utils.auto_shape(
            out_features, d=d, criterion=auto_shape_criterion, mode=auto_shape_mode)

            shape = [in_quantization, out_quantization]

        if init is None:
            if shape is None:
                raise ValueError(
                        "if init is not provided, please specify shape, or set auto_shapes=True")
        else:
            shape = init.raw_shape

        if init is None:
            init = t3.glorot_initializer(shape, tt_rank=tt_rank)

        self.shape = shape
        self.weight = init.to_parameter()
        self.parameters = self.weight.parameter
        self.weight_t = t3.transpose(self.weight)
        self.iter_num = iter_num
        self.L = l
        self.S = s
        self.epsilon = epsilon
        self.out_features = out_features

        if bias:
            self.bias = torch.nn.Parameter(1e-2 * torch.ones(out_features))
        else:
            self.register_parameter('bias', None)

    def forward(self, x):
        weight_t = self.weight_t
        #print('wight_t shape:', weight_t.shape)
        x_t = x.transpose(0, 1)
        #print('x_t shape:',x_t.shape)

        if self.bias is None:
            return t3.tt_dense_matmul(weight_t, x_t).transpose(0, 1)
        else:
            L = self.L
            S = self.S
            if self.iter_num == 1:
                if torch.norm(x) > self.epsilon:
                    return 1/L*(t3.tt_dense_matmul(weight_t,x_t).transpose(0,1)+self.bias)
                else:
                    return 1/L*(t3.tt_dense_matmul(weight_t,x_t).transpose(0,1)+self.bias) + S*torch.ones(self.out_features)
            else:
            # iter_num > 1
                if torch.norm(x) > self.epsilon:
                    x_l = 1/L*(t3.tt_dense_matmul(weight_t,x_t).transpose(0,1)+self.bias)
                else:
                    x_l = 1/L*(t3.tt_dense_matmul(weight_t,x_t).transpose(0,1)+self.bias) + S*torch.ones(self.out_features)
                #print('x_l shape:', x_l.shape)
            for i in range(1,self.iter_num):
                if torch.norm(x_l) > self.epsilon:
                    x_l = x_l - 1/L*t3.tt_dense_matmul(t3.tt_tt_mul(weight_t,self.weight),x_l.t()).transpose(0,1) + 1/L*t3.tt_dense_matmul(weight_t, x_t).transpose(0, 1) + self.bias
                else:
                    print('activated!!!')
                    x_l = x_l - 1/L*t3.tt_dense_matmul(t3.tt_tt_mul(weight_t,self.weight),x_l.t()).transpose(0,1) + 1/L*t3.tt_dense_matmul(weight_t, x_t).transpose(0, 1) + self.bias + S*torch.ones(self.out_features)
            return x_l
